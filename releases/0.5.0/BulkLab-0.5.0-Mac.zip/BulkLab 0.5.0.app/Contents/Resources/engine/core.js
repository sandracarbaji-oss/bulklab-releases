/* Mockup Studio 0.1 - independent personal implementation. ES3 compatible. */
(function () {
    function defaults() {
        return {templates:'~/Desktop/MockUP', designs:'~/Desktop/PNG', output:'~/Desktop/Salida',
            layer:'@design', fit:'fit', align:'top', jpg:true, png:false, psd:false,
            quality:12, recursive:false, pairing:'all', alignX:'center', scale:100, trim:true, organization:'design', naming:'design', templateRecursive:false, designRecursive:false, offsetX:0, offsetY:0, areaLeft:0, areaTop:0, areaWidth:100, areaHeight:100, maxEdge:0, crop:'original', targetKB:0, zone:'front', variants:false,twoSided:false, frontLayer:'@front', backLayer:'@back'};
    }
    function encode(s) {
        var d=defaults(), lines=['MockupStudio=1'], k;
        for(k in d) if(d.hasOwnProperty(k)) lines.push(k+'='+encodeURIComponent(String(s[k])));
        return lines.join('\n');
    }
    function decode(text) {
        var d=defaults(), lines=text.split(/\r\n|\r|\n/), i, at, k, v;
        if(lines[0]!=='MockupStudio=1') throw new Error('Formato de ajustes desconocido.');
        for(i=1;i<lines.length;i++) {
            at=lines[i].indexOf('='); if(at<1) continue;
            k=lines[i].substring(0,at); if(!d.hasOwnProperty(k)) continue;
            v=decodeURIComponent(lines[i].substring(at+1));
            if(typeof d[k]==='boolean') { if(v!=='true' && v!=='false') throw new Error('Ajuste invalido: '+k); d[k]=v==='true'; }
            else if(k==='offsetX'||k==='offsetY'||k==='areaLeft'||k==='areaTop'||k==='areaWidth'||k==='areaHeight'||k==='maxEdge'||k==='targetKB'){d[k]=Number(v);if(!isFinite(d[k]))throw new Error('Numero invalido: '+k);}
            else if(k==='quality'||k==='scale') {if(!/^\d+$/.test(v)||Number(v)>(k==='quality'?12:200)||(k==='scale'&&Number(v)<1)) throw new Error('Valor invalido: '+k); d[k]=Number(v);}
            else d[k]=v;
        }
        if(!/^(fit|fill|stretch)$/.test(d.fit)||!/^(top|center|bottom)$/.test(d.align)||!/^(all|pairs)$/.test(d.pairing)) throw new Error('Ajustes invalidos.');
        if(!/^(left|center|right)$/.test(d.alignX)||!/^(design|template|flat)$/.test(d.organization)||!/^(design|template)$/.test(d.naming)) throw new Error('Ajustes invalidos.');
        if(Math.abs(d.offsetX)>100||Math.abs(d.offsetY)>100||d.areaLeft<0||d.areaTop<0||d.areaWidth<=0||d.areaHeight<=0||d.areaLeft+d.areaWidth>100||d.areaTop+d.areaHeight>100)throw new Error('El area debe caber dentro del 100% del lienzo.');
        if(d.maxEdge<0||d.maxEdge>10000||d.targetKB<0||d.targetKB>20000)throw new Error('Limite de exportacion invalido.');
        if(!/^(original|square|landscape|portrait)$/.test(d.crop)||!/^(front|chest|back)$/.test(d.zone))throw new Error('Opcion invalida.');
        return d;
    }
    function fitRect(w,h,cw,ch,mode,align) {
        if(w<=0||h<=0||cw<=0||ch<=0) throw new Error('El diseno no tiene contenido visible.');
        var sx=cw/w, sy=ch/h;
        if(mode!=='stretch') sx=sy=mode==='fill'?Math.max(sx,sy):Math.min(sx,sy);
        var nw=w*sx, nh=h*sy;
        var point=position(nw,nh,cw,ch,'center',align);
        return {sx:sx*100,sy:sy*100,x:point.x,y:point.y};
    }
    function position(w,h,cw,ch,horizontal,vertical) {
        var x,y;
        if(horizontal==='left') x=0;
        else if(horizontal==='center') x=(cw-w)/2;
        else if(horizontal==='right') x=cw-w;
        else throw new Error('Posicion horizontal invalida.');
        if(vertical==='top') y=0;
        else if(vertical==='center') y=(ch-h)/2;
        else if(vertical==='bottom') y=ch-h;
        else throw new Error('Posicion vertical invalida.');
        return {x:x,y:y};
    }
    function safeName(name) {
        return name.replace(/\.[^.]+$/,'').replace(/[\x00-\x1f<>:"\/\\|?*]/g,'_').replace(/[. ]+$/g,'').substring(0,90)||'Sin_nombre';
    }
    function count(nt,nd,pairing) {
        if(pairing==='pairs' && nt!==nd) throw new Error('Para combinar por orden, ambas carpetas deben tener el mismo numero de archivos.');
        return pairing==='pairs'?nt:nt*nd;
    }
    function job(index,nt,nd,pairing) {
        return pairing==='pairs'?{template:index,design:index}:{template:Math.floor(index/nd),design:index%nd};
    }
    function normalize(input) {
        var d=defaults(),k;
        for(k in d)if(d.hasOwnProperty(k)&&input&&input[k]!==undefined)d[k]=input[k];
        return decode(encode(d));
    }
    function json(v) {
        if(v===null||v===undefined)return 'null';
        if(typeof v==='boolean')return v?'true':'false';
        if(typeof v==='number')return isFinite(v)?String(v):'null';
        if(typeof v==='string')return '"'+v.replace(/[\\"\x00-\x1f]/g,function(c){var n=c.charCodeAt(0).toString(16);return '\\u'+('0000'+n).slice(-4);})+'"';
        var a=[],k;
        if(Object.prototype.toString.call(v)==='[object Array]'){for(k=0;k<v.length;k++)a.push(json(v[k]));return '['+a.join(',')+']';}
        for(k in v)if(v.hasOwnProperty(k))a.push(json(k)+':'+json(v[k]));
        return '{'+a.join(',')+'}';
    }

    function parse(text) {
        var i=0;
        function ws(){var c;while(i<text.length){c=text.charCodeAt(i);if(c!==32&&c!==9&&c!==10&&c!==13)break;i++;}}
        function stringValue(){
            i++;var out='',start=i,end,slash,c,h,m={'"':'"','\\':'\\','/':'/','b':'\b','f':'\f','n':'\n','r':'\r','t':'\t'};
            while(i<text.length){
                end=text.indexOf('"',i);if(end<0)throw Error('JSON string');
                slash=text.substring(i,end).indexOf('\\');if(slash>=0)slash+=i;
                if(slash<0||slash>end){var chunk=text.substring(i,end);if(/[\x00-\x1f]/.test(chunk))throw Error('JSON control');out+=chunk;i=end+1;return out;}
                var chunk=text.substring(i,slash);if(/[\x00-\x1f]/.test(chunk))throw Error('JSON control');out+=chunk;i=slash+1;c=text.charAt(i++);
                if(c==='u'){h=text.substr(i,4);if(!/^[0-9a-fA-F]{4}$/.test(h))throw Error('JSON unicode');out+=String.fromCharCode(parseInt(h,16));i+=4;}
                else{if(!m.hasOwnProperty(c))throw Error('JSON escape');out+=m[c];}
            }
            throw Error('JSON string');
        }
        function value(){ws();var c=text.charAt(i),a,k;
            if(c==='"')return stringValue();
            if(c==='['){i++;a=[];ws();if(text.charAt(i)===']'){i++;return a;}while(true){a.push(value());ws();c=text.charAt(i++);if(c===']')return a;if(c!==',')throw Error('JSON array');}}
            if(c==='{'){i++;a={};ws();if(text.charAt(i)==='}'){i++;return a;}while(true){ws();if(text.charAt(i)!=='"')throw Error('JSON key');k=value();if(k==='__proto__'||k==='constructor'||k==='prototype')throw Error('JSON key');ws();if(text.charAt(i++)!==':')throw Error('JSON colon');a[k]=value();ws();c=text.charAt(i++);if(c==='}')return a;if(c!==',')throw Error('JSON object');}}
            if(c==='-'||(c>='0'&&c<='9')){
                var start=i;while(i<text.length&&/[0-9eE+.-]/.test(text.charAt(i)))i++;
                var token=text.substring(start,i);if(!/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(token))throw Error('JSON numero');
                var number=Number(token);if(!isFinite(number))throw Error('JSON numero');return number;
            }
            if(text.substr(i,4)==='true'){i+=4;return true;}if(text.substr(i,5)==='false'){i+=5;return false;}if(text.substr(i,4)==='null'){i+=4;return null;}throw Error('JSON valor');
        }
        var result=value();ws();if(i!==text.length)throw Error('JSON sobrante');return result;
    }
    var placementKeys=['fit','align','alignX','scale','trim','offsetX','offsetY','areaLeft','areaTop','areaWidth','areaHeight','layer'];
    function effective(settings,profiles,path){var d=normalize(settings),list=[profiles['$global::'+d.zone],profiles['$'+path+'::'+d.zone]],j,i,k,p;for(j=0;j<list.length;j++){p=list[j];if(p)for(i=0;i<placementKeys.length;i++){k=placementKeys[i];if(p[k]!==undefined)d[k]=p[k];}}return normalize(d);}
    function place(w,h,cw,ch,s){var aw=cw*s.areaWidth/100,ah=ch*s.areaHeight/100,p=position(w,h,aw,ah,s.alignX,s.align);p.x+=cw*s.areaLeft/100+aw*s.offsetX/100;p.y+=ch*s.areaTop/100+ah*s.offsetY/100;return p;}
    function designPairs(files,two){var out=[],map={},i,f,stem,key,side,p;
        if(!two){for(i=0;i<files.length;i++)out.push({front:files[i],back:null,name:files[i].name});return out;}
        for(i=0;i<files.length;i++){f=files[i];stem=f.path;var extensionAt=stem.lastIndexOf('.'),slashAt=stem.lastIndexOf('/');if(extensionAt>slashAt)stem=stem.substring(0,extensionAt);if(!/_(front|back)$/i.test(stem))continue;side=/_back$/i.test(stem)?'back':'front';key='$'+stem.replace(/_(front|back)$/i,'');if(!map[key])map[key]={name:f.name.replace(/_(front|back)\.[^.]+$/i,'')};if(map[key][side])throw Error('Hay mas de un archivo para '+key);map[key][side]=f;}
        for(key in map)if(map.hasOwnProperty(key)){p=map[key];if(!p.front||!p.back)throw Error('Falta _front o _back para '+p.name);out.push(p);}
        if(!out.length)throw Error('Usa archivos Nombre_front.png y Nombre_back.png.');out.sort(function(a,b){if(a.front.path<b.front.path)return -1;if(a.front.path>b.front.path)return 1;return 0;});return out;
    }
    function sampleIndices(total,limit){
        var out=[],count=Math.min(total,limit),i;
        if(count<=0)return out;
        for(i=0;i<count;i++)out.push(count===1?0:Math.floor(i*(total-1)/(count-1)));
        return out;
    }
    function pending(jobs,mode){var out=[];for(var i=0;i<jobs.length;i++){var st=jobs[i].status;if((mode==='retry'&&st==='error')||(mode!=='retry'&&(st==='pending'||st==='running')))out.push(i);}return out;}

    function catalog(files){
        var groups={},out=[],i,f,path,slash,dot,stem,match,side,tone,id,g,slot;
        for(i=0;i<files.length;i++){
            f=files[i];path=f.path;slash=path.lastIndexOf('/');dot=path.lastIndexOf('.');if(dot<=slash)continue;
            stem=path.substring(slash+1,dot);side='front';tone='neutral';
            match=/_(claras|oscuras)$/i.exec(stem);if(match){tone=match[1].toLowerCase();stem=stem.substring(0,stem.length-match[0].length);}
            match=/_(front|back)$/i.exec(stem);if(match){side=match[1].toLowerCase();stem=stem.substring(0,stem.length-match[0].length);}
            if(!stem)throw Error('Falta el nombre base del diseno: '+f.name);
            id=path.substring(0,slash+1)+stem;slot=side+'_'+tone;
            g=groups['$'+id];if(!g){g={id:id,name:stem,front:{path:id},variants:{}};groups['$'+id]=g;out.push(g);}
            if(g.variants[slot])throw Error('Variante duplicada: '+stem+' '+slot);
            g.variants[slot]=f;
        }
        out.sort(function(a,b){if(a.id<b.id)return -1;if(a.id>b.id)return 1;return 0;});return out;
    }
    function rule(input){
        var r={tone:'',view:'front',frontLayer:'@design',backLayer:'@design'},k;
        for(k in r)if(r.hasOwnProperty(k)&&input&&input[k]!==undefined)r[k]=input[k];
        if(!/^(claras|oscuras)$/.test(r.tone))throw Error('Elige Clara u Oscura para este mockup.');
        if(!/^(front|back|both)$/.test(r.view))throw Error('Vista de mockup invalida.');
        if((r.view!=='back'&&!String(r.frontLayer).replace(/\s/g,''))||(r.view!=='front'&&!String(r.backLayer).replace(/\s/g,'')))throw Error('Indica las capas de cada cara.');
        if(r.view==='both'&&r.frontLayer===r.backLayer)throw Error('Frente y espalda necesitan capas distintas.');return r;
    }
    function resolveSurfaces(design,templateRule,designRule,settings,profiles,path){
        var r=rule(templateRule),dr=designRule||{},sides=['front','back'],out=[],i,side,blank,file,c,zone;
        for(i=0;i<sides.length;i++){
            side=sides[i];if(r.view!=='both'&&r.view!==side)continue;
            blank=dr[side+'Blank']===true;file=null;
            if(!blank){
                file=design.variants[side+'_'+r.tone]||design.variants[side+'_neutral'];
                if(!file)throw Error('Falta '+design.name+'_'+side+'_'+r.tone+'.png (o marca esa cara Sin estampado).');
            }
            c=normalize(settings);zone='front';if(side==='back')zone='back';else if(settings.zone==='chest')zone='chest';c.zone=zone;
            out.push({side:side,blank:blank,design:file,layer:r[side+'Layer'],settings:effective(c,profiles,path)});
        }
        return out;
    }

    return {sampleIndices:sampleIndices,catalog:catalog,rule:rule,resolveSurfaces:resolveSurfaces,parse:parse,place:place,effective:effective,designPairs:designPairs,pending:pending,placementKeys:placementKeys,position:position,normalize:normalize,json:json,defaults:defaults,encode:encode,decode:decode,fitRect:fitRect,safeName:safeName,count:count,job:job};
}());
