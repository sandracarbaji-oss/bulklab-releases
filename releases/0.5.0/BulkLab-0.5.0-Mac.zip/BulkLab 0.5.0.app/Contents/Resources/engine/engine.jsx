#target photoshop
/* Mockup Studio 1.3.2. Original code, independent of Bulk Mockups Filler. */
(function () {
    var requestStarted=new Date().getTime(),metrics={readMs:0,writeMs:0,parseMs:0,encodeMs:0};
    var root = new File($.fileName).parent;
    var request=$.global.BulkLabRequest||null;
    try{delete $.global.BulkLabRequest;}catch(ignore){}
    function L(es,en){if(request&&request.language==='en')return en;return es;}
    var example = $.global.BulkLabExample || null;
    try {delete $.global.BulkLabExample;} catch(ignore) {}
    var coreKey=root.fsName+'::1.3.2';
    if(!$.global.BulkLabCore||$.global.BulkLabCore.key!==coreKey)$.global.BulkLabCore={key:coreKey,value:$.evalFile(new File(root.fsName+'/core.js'))};
    var Core=$.global.BulkLabCore.value;
    var dataFolder = new Folder(Folder.userData.fsName + '/BulkLab/engine');
    var settingsFile = new File(dataFolder.fsName + '/settings-v1.txt');
    function measuredParse(text){var t=new Date().getTime();try{return Core.parse(text);}finally{metrics.parseMs+=new Date().getTime()-t;}}
    function measuredEncode(value){var t=new Date().getTime();try{return Core.json(value);}finally{metrics.encodeMs+=new Date().getTime()-t;}}
    function diagnostic(event){
        if(!request||!request.diagnostics)return;
        try{if(!dataFolder.exists)dataFolder.create();var f=new File(dataFolder.fsName+'/Diagnostics-1.3.2.jsonl');f.encoding='UTF-8';if(f.open('a')){try{event.atMs=new Date().getTime();f.writeln(Core.json(event));}finally{f.close();}}}catch(ignore){}
    }
    function readText(f) {
        var ioStarted=new Date().getTime();
        f.encoding='UTF-8'; if(!f.open('r')) throw new Error('No se pudo leer '+f.fsName);
        var text; try {text=f.read();} finally {f.close();metrics.readMs+=new Date().getTime()-ioStarted;} return text;
    }
    function writeText(f,text) {
        var ioStarted=new Date().getTime();
        f.encoding='UTF-8'; if(!f.open('w')) throw new Error('No se pudo guardar '+f.fsName);
        try {if(!f.write(text)) throw new Error('Error al escribir '+f.fsName);} finally {f.close();metrics.writeMs+=new Date().getTime()-ioStarted;}
    }
    function saveSettings(s) {
        s=Core.normalize(s);
        if(!dataFolder.exists&&!dataFolder.create()) throw new Error('No se pudo crear la carpeta de ajustes.');
        var next=new File(settingsFile.fsName+'.new'), back=new File(settingsFile.fsName+'.bak');
        writeText(next,Core.encode(s));
        Core.decode(readText(next));
        if(settingsFile.exists) {
            if(!settingsFile.copy(back.fsName)) throw new Error('No se pudo respaldar la configuracion.');
            if(!settingsFile.remove()) throw new Error('No se pudo actualizar la configuracion.');
        }
        if(!next.rename(settingsFile.name)) {
            if(back.exists) back.copy(settingsFile.fsName);
            throw new Error('No se pudo finalizar el guardado.');
        }
    }
    function loadSettings() {
        var back=new File(settingsFile.fsName+'.bak');
        if(settingsFile.exists) {
            try {return Core.decode(readText(settingsFile));}
            catch(e) {alert(L('No se pudieron leer los ultimos ajustes. Se intentara recuperar la copia anterior.','Could not read the latest settings. Trying the previous backup.'));}
        }
        if(back.exists) {try{return Core.decode(readText(back));}catch(ignore){}}
        return Core.defaults();
    }
    function filesIn(folder,pattern,recursive,seen) {
        seen=seen||{};
        var key='$'+folder.fsName, list=[], entries, i, item;
        if(seen[key]) return list; seen[key]=true;
        entries=folder.getFiles();
        for(i=0;i<entries.length;i++) {
            item=entries[i];
            if(item.alias || item.name.charAt(0)==='.') continue;
            if(item instanceof Folder) {if(recursive) list=list.concat(filesIn(item,pattern,true,seen));}
            else if(pattern.test(item.name)) list.push(item);
        }
        list.sort(function(a,b){var x=a.fsName.toLowerCase(),y=b.fsName.toLowerCase();if(x<y)return -1;if(x>y)return 1;return 0;});
        return list;
    }
    function isInside(child,parent) {
        var c=child.fsName.toLowerCase(),p=parent.fsName.toLowerCase();
        return c===p||c.indexOf(p+'/')===0;
    }
    function plan(s,one,catalogOnly) {
        var tf=new Folder(s.templates), df=new Folder(s.designs), of=new Folder(s.output);
        if(!tf.exists||!df.exists) throw new Error('Elige carpetas existentes para mockups y disenos.');
        // A missing output folder is created by newRun, after confirmation.
        if(!catalogOnly){
        if(isInside(of,tf)||isInside(of,df)) throw new Error('La carpeta de salida debe estar fuera de las carpetas de entrada.');
        if(!s.layer.replace(/\s/g,'')) throw new Error('Escribe el nombre de la capa de diseno.');
        if(!s.jpg&&!s.png&&!s.psd) throw new Error('Elige al menos un formato de salida.');
        }
        var t=filesIn(tf,/\.(psd|psb)$/i,s.templateRecursive||s.recursive), d=filesIn(df,/\.(png|jpe?g|tiff?|psd|psb)$/i,s.designRecursive||s.recursive);
        if(!t.length||!d.length) throw new Error('No se encontraron mockups PSD/PSB o imagenes de diseno.');
        var count=Core.count(t.length,d.length,s.pairing);
        return {templates:t,designs:d,output:of,total:one?1:count,fullCount:count};
    }
    function sID(s){return stringIDToTypeID(s);}
    function findLayers(container,name,out) {
        for(var i=0;i<container.layers.length;i++) {
            var layer=container.layers[i];
            if(!layer.visible) continue;
            if(layer.typename==='LayerSet') findLayers(layer,name,out);
            else if(layer.name===name&&layer.kind===LayerKind.SMARTOBJECT) out.push(layer);
        }
    }
    function ensureEmbedded(layer) {
        var ref=new ActionReference();ref.putIdentifier(sID('layer'),layer.id);
        var desc=executeActionGet(ref), key=sID('smartObject');
        if(!desc.hasKey(key))throw new Error('La capa '+layer.name+' no contiene un objeto inteligente.');
        var smart=desc.getObjectValue(key);
        if(smart.hasKey(sID('linked'))&&smart.getBoolean(sID('linked'))) throw new Error('La capa '+layer.name+' esta vinculada. Incrustala en una copia del mockup antes de usarla.');
        if(smart.hasKey(sID('fileReference'))&&/\.(ai|pdf|eps|svg)$/i.test(smart.getString(sID('fileReference')))) throw new Error('Esta version requiere objetos inteligentes de imagen, no vectoriales.');
    }
    function ids() {var list=[];for(var i=0;i<app.documents.length;i++)list.push(app.documents[i].id);return list;}
    function contains(list,id){for(var i=0;i<list.length;i++)if(list[i]===id)return true;return false;}
    function pixels(layer) {
        var b=layer.bounds;
        return [Number(b[0].as('px')),Number(b[1].as('px')),Number(b[2].as('px')),Number(b[3].as('px'))];
    }
    function selectOnly(layer) {
        var r=new ActionReference(),d=new ActionDescriptor();
        r.putIdentifier(charIDToTypeID('Lyr '),layer.id);
        d.putReference(charIDToTypeID('null'),r);
        d.putBoolean(stringIDToTypeID('makeVisible'),false);
        executeAction(charIDToTypeID('slct'),d,DialogModes.NO);
    }
    function movePixels(layer,dx,dy) {
        selectOnly(layer);
        var r=new ActionReference(),d=new ActionDescriptor(),o=new ActionDescriptor();
        r.putEnumerated(charIDToTypeID('Lyr '),charIDToTypeID('Ordn'),charIDToTypeID('Trgt'));
        d.putReference(charIDToTypeID('null'),r);
        o.putUnitDouble(charIDToTypeID('Hrzn'),charIDToTypeID('#Pxl'),dx);
        o.putUnitDouble(charIDToTypeID('Vrtc'),charIDToTypeID('#Pxl'),dy);
        d.putObject(charIDToTypeID('T   '),charIDToTypeID('Ofst'),o);
        executeAction(charIDToTypeID('move'),d,DialogModes.NO);
    }
    function editSmart(doc,layer,design,s,log) {
        app.activeDocument=doc;doc.activeLayer=layer;selectOnly(layer);ensureEmbedded(layer);
        var before=ids(),child=null,source=null;
        try {
            executeAction(sID('placedLayerEditContents'),new ActionDescriptor(),DialogModes.NO);
            if(app.activeDocument.id===doc.id||contains(before,app.activeDocument.id))throw new Error('Cierra las ventanas de objetos inteligentes y vuelve a probar.');
            child=app.activeDocument;
            child.selection.deselect();
            child.rulerOrigin=[0,0];
            var cw=Number(child.width.as('px')),ch=Number(child.height.as('px'));
            log('ALINEACION | '+layer.name+' | lienzo='+cw+'x'+ch+' | modo='+s.align);
            for(var i=0;i<child.layers.length;i++)child.layers[i].visible=false;
            // Transfer pixels, avoiding a second nested smart-object transform.
            source=design.document;app.activeDocument=source;
            var placed=source.activeLayer.duplicate(child,ElementPlacement.PLACEATBEGINNING);
            source=null;
            app.activeDocument=child;child.activeLayer=placed;selectOnly(placed);
            placed.name='Diseno';placed.visible=true;placed.allLocked=false;
            var b=pixels(placed),f=Core.fitRect(s.trim===false?design.width:b[2]-b[0],s.trim===false?design.height:b[3]-b[1],cw*s.areaWidth/100,ch*s.areaHeight/100,s.fit,s.align);
            log('ALINEACION | antes='+b.join(',')+' | escala='+f.sx+','+f.sy);
            placed.resize(f.sx*(s.scale||100)/100,f.sy*(s.scale||100)/100,AnchorPosition.TOPLEFT);
            b=pixels(placed);
            var width=b[2]-b[0],height=b[3]-b[1];
            var target=Core.place(s.trim===false?design.width*f.sx*s.scale/10000:width,s.trim===false?design.height*f.sy*s.scale/10000:height,cw,ch,s);
            var tx=target.x,ty=target.y;
            if(s.trim===false){tx+=design.bounds[0]*f.sx*s.scale/10000;ty+=design.bounds[1]*f.sy*s.scale/10000;}
            log('ALINEACION | escalado='+b.join(',')+' | destino='+tx+','+ty);
            movePixels(placed,tx-b[0],ty-b[1]);
            b=pixels(placed);
            log('ALINEACION | final='+b.join(','));
            if(Math.abs(b[0]-tx)>2||Math.abs(b[1]-ty)>2)throw new Error('La verificacion de posicion fallo; no se exporto esta combinacion.');
            child.save();child.close(SaveOptions.DONOTSAVECHANGES);child=null;
        }finally{
            
            if(child){try{child.close(SaveOptions.DONOTSAVECHANGES);}catch(ignore){}}
            app.activeDocument=doc;
        }
    }
    function duplicateTemplate(file,merge) {
        var source=null,opened=false,copy=null;
        for(var i=0;i<app.documents.length;i++) {
            try{if(app.documents[i].fullName.fsName===file.fsName)source=app.documents[i];}catch(ignore){}
        }
        if(source&&!source.saved)throw Error('Guarda o cierra los cambios del archivo '+file.name+' antes de generar.');
        if(!source){source=app.open(file);opened=true;}
        try {copy=source.duplicate('Mockup Studio · '+Core.safeName(file.name),Boolean(merge));}
        finally {if(opened)source.close(SaveOptions.DONOTSAVECHANGES);}
        app.activeDocument=copy;return copy;
    }
    // Store IDs, never history-state or stale Photoshop DOM references.
    function documentById(id){for(var i=0;i<app.documents.length;i++)if(app.documents[i].id===id)return app.documents[i];return null;}
    function releaseTemplateCache(){
        var cache=$.global.BulkLabTemplateCache;
        if(cache){var base=documentById(cache.id);if(base)base.close(SaveOptions.DONOTSAVECHANGES);delete $.global.BulkLabTemplateCache;}
    }
    function cachedTemplate(file){
        var key=file.fsName+'|'+file.length+'|'+file.modified.getTime(),cache=$.global.BulkLabTemplateCache;
        var base=cache&&cache.key===key?documentById(cache.id):null;
        if(!base){releaseTemplateCache();base=duplicateTemplate(file);$.global.BulkLabTemplateCache={key:key,id:base.id};}
        app.activeDocument=base;
        return base.duplicate('Mockup Studio - trabajo',false);
    }
    function prepareDesign(file,tempFolder,s) {
        var copy=duplicateTemplate(file,true);
        try {
            if(s.trim!==false)copy.trim(TrimType.TRANSPARENT,true,true,true,true);
            // Transfer directly from memory; no temporary PSD save and reopen.
            return {document:copy,width:Number(copy.width.as('px')),height:Number(copy.height.as('px')),bounds:pixels(copy.activeLayer),remove:function(){copy.close(SaveOptions.DONOTSAVECHANGES);}};
        }catch(e){try{copy.close(SaveOptions.DONOTSAVECHANGES);}catch(ignore){}throw e;}
    }
    function exportFiles(doc,folder,base,designName,templateName,s,simple) {
        var result=[],copy=null;
        function destination(type,extension) {
            var typeFolder=folder;if(!simple)typeFolder=new Folder(folder.fsName+'/'+type);
            if(!typeFolder.exists&&!typeFolder.create())throw new Error('No se pudo crear '+typeFolder.fsName);
            var designFolder=typeFolder;if(simple==='design')designFolder=new Folder(typeFolder.fsName+'/'+designName);
            if(!simple&&s.organization!=='flat')designFolder=new Folder(typeFolder.fsName+'/'+(s.organization==='template'?templateName:designName));
            if(!designFolder.exists&&!designFolder.create())throw new Error('No se pudo crear '+designFolder.fsName);
            var file=new File(designFolder.fsName+'/'+base+'.'+extension),n=2;
            while(file.exists)file=new File(designFolder.fsName+'/'+base+'_'+(n++)+'.'+extension);
            return file;
        }
        if(s.psd) {
            var p=new PhotoshopSaveOptions();p.layers=true;p.embedColorProfile=true;
            var pf=destination('PSD','psd');doc.saveAs(pf,p,true,Extension.LOWERCASE);result.push(pf.fsName);
        }
        if(s.jpg||s.png) {
            copy=doc.duplicate('Exportacion Mockup Studio',false);
            try {
                if(copy.mode!==DocumentMode.RGB)copy.changeMode(ChangeMode.RGB);
                copy.bitsPerChannel=BitsPerChannelType.EIGHT;
                copy.convertProfile('sRGB IEC61966-2.1',Intent.RELATIVECOLORIMETRIC,true,true);
                var ew=Number(copy.width.as('px')),eh=Number(copy.height.as('px')),ratio=0;
                if(s.crop==='square')ratio=1;else if(s.crop==='landscape')ratio=4/3;else if(s.crop==='portrait')ratio=4/5;
                if(ratio){var nw=ew,nh=eh;if(ew/eh>ratio)nw=eh*ratio;else nh=ew/ratio;copy.crop([UnitValue((ew-nw)/2,'px'),UnitValue((eh-nh)/2,'px'),UnitValue((ew+nw)/2,'px'),UnitValue((eh+nh)/2,'px')]);ew=nw;eh=nh;}
                if(s.maxEdge>0&&Math.max(ew,eh)>s.maxEdge){var factor=s.maxEdge/Math.max(ew,eh);copy.resizeImage(UnitValue(Math.round(ew*factor),'px'),UnitValue(Math.round(eh*factor),'px'),null,ResampleMethod.BICUBIC);}
                if(s.png){var n=new PNGSaveOptions();var nf=destination('PNG','png');copy.saveAs(nf,n,true,Extension.LOWERCASE);result.push(nf.fsName);}
                if(s.jpg){copy.flatten();var j=new JPEGSaveOptions();j.quality=s.quality;j.embedColorProfile=true;var jf=destination('JPG','jpg');copy.saveAs(jf,j,true,Extension.LOWERCASE);
                    while(s.targetKB>0&&new File(jf.fsName).length>s.targetKB*1024&&j.quality>3){j.quality--;copy.saveAs(jf,j,true,Extension.LOWERCASE);}
                    result.push(jf.fsName);}
            }finally{copy.close(SaveOptions.DONOTSAVECHANGES);}
        }
        return result;
    }
    function stamp() {
        var d=new Date();function pad(n){return n<10?'0'+n:String(n);}
        return d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+'_'+pad(d.getHours())+pad(d.getMinutes())+pad(d.getSeconds());
    }
    var stateFile=new File(dataFolder.fsName+'/studio-v2.json');
    function atomic(file,value){
        var next=new File(file.fsName+'.new'),back=new File(file.fsName+'.bak');
        writeText(next,measuredEncode(value));measuredParse(readText(next));
        if(file.exists){if(!file.copy(back.fsName)||!file.remove())throw Error('No se pudo respaldar '+file.name);}
        if(!next.rename(file.name)){if(back.exists)back.copy(file.fsName);throw Error('No se pudo guardar '+file.name);}
    }
    function loadJSON(file,fallback){if(file.exists){try{return measuredParse(readText(file));}catch(e){var back=new File(file.fsName+'.bak');if(back.exists)return measuredParse(readText(back));throw e;}}var back=new File(file.fsName+'.bak');if(back.exists)return measuredParse(readText(back));return fallback;}
    function loadRun(path){
        var cached=$.global.BulkLabRun;
        if(cached&&cached.path===path)return cached;
        var m=loadJSON(new File(path),null);if(!m)return null;
        if(m.version===9){
            var folder=new Folder(new File(path).parent.fsName+'/jobs');
            var files=folder.exists?folder.getFiles():[],seen={};
            for(var i=0;i<files.length;i++){
                var match=/^(\d+)\.json(?:\.bak)?$/.exec(files[i].name);if(!match||seen['$'+match[1]])continue;seen['$'+match[1]]=true;
                var index=Number(match[1]);if(index>=m.jobs.length)continue;
                var update=loadJSON(new File(folder.fsName+'/'+index+'.json'),null);
                if(update&&update.id===m.jobs[index].id){var j=m.jobs[index];j.status=update.status;j.files=update.files;j.error=update.error;j.timings=update.timings;}
            }
        }
        $.global.BulkLabRun=m;return m;
    }
    function checkpoint(m,job){
        if(m.version!==9){atomic(new File(m.path),m);return;}
        var folder=new Folder(new File(m.path).parent.fsName+'/jobs');mkdir(folder);
        atomic(new File(folder.fsName+'/'+job.id+'.json'),{id:job.id,status:job.status,files:job.files,error:job.error,timings:job.timings||null});
    }
    function loadState(){var state=loadJSON(stateFile,{profiles:{},tags:{},favorites:{},excluded:{},thumbnails:{},reviews:{},lastRun:'',lastGallery:''});if(!state.templateRules)state.templateRules={};if(!state.designRules)state.designRules={};return state;}
    function saveState(st){if(!dataFolder.exists&&!dataFolder.create())throw Error('No se pudo crear la carpeta de ajustes.');atomic(stateFile,st);}
    function meta(f){return {name:decodeURI(f.name),path:f.fsName,size:f.length,modified:f.modified?f.modified.getTime():0};}
    function metadata(files){var a=[];for(var i=0;i<files.length;i++)a.push(meta(files[i]));return a;}
    function checkSource(m){if(!m)return;var f=new File(m.path);if(!f.exists||f.length!==m.size||(f.modified?f.modified.getTime():0)!==m.modified)throw Error('El archivo cambio o falta: '+m.name+'. Crea un lote nuevo.');}
    function runSummary(m){var x={done:0,pending:0,error:0,total:m.jobs.length,path:m.path,kind:m.kind};for(var i=0;i<m.jobs.length;i++){var s=m.jobs[i].status;if(s==='done')x.done++;else if(s==='error')x.error++;else x.pending++;}return x;}
    function fileList(files){return metadata(files);}
    function designCatalog(files,c){if(c.variants)return Core.catalog(metadata(files));return Core.designPairs(metadata(files),c.twoSided);}
    function templateRule(st,path){
        var r=st.templateRules['$'+path];if(r)return r;
        var tone='';if(st.tags['$'+path]==='Claras')tone='claras';if(st.tags['$'+path]==='Oscuras')tone='oscuras';
        return {tone:tone,view:'front',frontLayer:'@design',backLayer:'@design'};
    }
    function newRun(c,b,r,st){
        var templates=[],designs=designCatalog(b.designs,c),i,j;
        for(i=0;i<b.templates.length;i++){var f=b.templates[i];if(r.action==='preview'){if(f.fsName===r.template)templates.push(meta(f));}else if(!st.excluded['$'+f.fsName])templates.push(meta(f));}
        if(r.action!=='run'&&r.action!=='quick'){var selected=[];for(i=0;i<designs.length;i++)if(designs[i].front.path===r.design)selected.push(designs[i]);designs=selected;}
        if(!templates.length||!designs.length)throw Error('Selecciona mockups y un diseno valido.');
        var count=templates.length*designs.length;
        if((r.action==='run'||r.action==='quick')&&c.pairing==='pairs')count=Core.count(templates.length,designs.length,'pairs');
        var pairing=(r.action==='run'||r.action==='quick')?c.pairing:'all',indices=[],fullCount=count;
        if(r.action==='quick')indices=Core.sampleIndices(count,3);else for(i=0;i<count;i++)indices.push(i);
        count=indices.length;
        var preflight=[],issues=[],seenIssues={};
        function addIssue(t,d,message,field){var key='$'+t.path+'|'+(field==='ruleTone'?'':d.front.path)+'|'+message;if(seenIssues[key])return;seenIssues[key]=true;issues.push({template:t.path,templateName:t.name,design:d.front.path,designName:d.name,message:message,field:field});}
        if(c.variants){for(var pi=0;pi<count;pi++){
            var ix=Core.job(indices[pi],templates.length,designs.length,pairing),pt=templates[ix.template],pd=designs[ix.design],rule=templateRule(st,pt.path);
            if(!rule.tone){addIssue(pt,pd,L('Elige si esta camiseta es clara u oscura.','Choose whether this garment is light or dark.'),'ruleTone');continue;}
            try{preflight[pi]=Core.resolveSurfaces(pd,rule,st.designRules['$'+pd.id],c,st.profiles,pt.path);}
            catch(e){
                var missing=/^Falta /.test(e.message),back=/_back_/.test(e.message),field=missing?(back?'designBack':'designFront'):'ruleView';
                var message=missing?L('Falta el archivo de '+(back?'espalda':'frente')+' para '+rule.tone+'. Añade la variante o marca esa cara Sin estampado.','The '+(back?'back':'front')+' artwork for '+rule.tone+' is missing. Add that variant or mark this side Blank.'):e.message;
                if(rule.view==='both'&&rule.frontLayer===rule.backLayer){field='ruleBack';message=L('Frente y espalda necesitan objetos inteligentes con nombres diferentes.','Front and back need smart objects with different layer names.');}
                addIssue(pt,pd,message,field);
            }
        }}
        var formats=r.action==='run'?[c.jpg?'JPG':'',c.png?'PNG':'',c.psd?'PSD':'']:['JPG'],chosenFormats=[];
        for(i=0;i<formats.length;i++)if(formats[i])chosenFormats.push(formats[i]);
        var signature=Core.json({action:r.action,settings:c,templates:templates,designs:designs,profiles:st.profiles,templateRules:st.templateRules,designRules:st.designRules});
        var summary={combinations:count,images:count*chosenFormats.length,formats:chosenFormats,folder:b.output.fsName+(r.action==='run'?'':'/Revisiones'),issues:issues,fullCount:fullCount,examples:[]};
        for(i=0;i<Math.min(count,3);i++){var ex=Core.job(indices[i],templates.length,designs.length,pairing);summary.examples.push({template:templates[ex.template].name,design:designs[ex.design].name});}
        if(r.inspect){var token=String(new Date().getTime())+'-'+String(Math.random());$.global.BulkLabPlan={token:token,signature:signature};summary.token=token;return summary;}
        if(issues.length){var err=Error(L('Hay ajustes que corregir antes de generar.','Some settings need attention before generating.'));err.issues=issues;throw err;}
        if(r.planToken){var approved=$.global.BulkLabPlan;delete $.global.BulkLabPlan;if(!approved||approved.token!==r.planToken||approved.signature!==signature)throw Error(L('Los archivos o ajustes cambiaron. Revisa de nuevo el resumen.','Files or settings changed. Review the summary again.'));}
        else if(!confirm(L('Generar '+count+' combinaciones?','Generate '+count+' combinations?')))return null;
        var folder=b.output;if(r.action!=='run')folder=new Folder(b.output.fsName+'/Revisiones');mkdir(folder);
        var runs=new Folder(dataFolder.fsName+'/runs');mkdir(runs);
        var base=runs.fsName+'/Lote_'+stamp(),internal=new Folder(base),n=1;while(internal.exists)internal=new Folder(base+'_'+n++);mkdir(internal);
        var m={version:9,path:internal.fsName+'/Lote.json',report:internal.fsName+'/Resumen.txt',folder:folder.fsName,kind:r.action,jobs:[],settings:c};
        for(i=0;i<count;i++){
            var index=Core.job(indices[i],templates.length,designs.length,pairing);
            var t=templates[index.template],d=designs[index.design],front=Core.normalize(c);if(c.twoSided)front.zone='front';
            var s=Core.effective(front,st.profiles,t.path),back=null;
            if(c.twoSided){var bs=Core.normalize(c);bs.zone='back';back=Core.effective(bs,st.profiles,t.path);}
            if(r.action!=='run'){s.jpg=true;s.png=false;s.psd=false;if(back){back.jpg=true;back.png=false;back.psd=false;}}
            var job={id:String(i),template:t,design:d.front,back:d.back,name:d.name,settings:s,backSettings:back,status:'pending',files:[],error:''};
            if(c.variants){job.surfaces=preflight[i];job.design=null;job.back=null;job.view=Core.rule(templateRule(st,t.path)).view;job.tone=Core.rule(templateRule(st,t.path)).tone;}
            job.brand=labelForBrand(t.path);if(brandContext&&brandContext.kind==='all')job.brandFolder=Core.safeName(job.brand+'.folder');
            m.jobs.push(job);
        }
        atomic(new File(m.path),m);$.global.BulkLabRun=m;if(r.action==='run')st.lastRun=m.path;else if(r.action==='gallery'||r.action==='quick')st.lastGallery=m.path;saveState(st);return m;
    }
    function outputMode(m){if(m.version>=8)return 'design';return m.version===7;}
    function executeRun(m,mode,jobId){
        if((m.version!==5&&m.version!==6&&m.version!==7&&m.version!==8&&m.version!==9)||!m.jobs||!new Folder(m.folder).exists)throw Error('Lote no compatible o carpeta ausente.');
        var indices=Core.pending(m.jobs,mode),folder=new Folder(m.folder),file=new File(m.path);
        if(jobId!==undefined){var chosen=[];for(var ii=0;ii<indices.length;ii++)if(m.jobs[indices[ii]].id===jobId)chosen.push(indices[ii]);indices=chosen;}
        if(!indices.length)return {manifest:m,summary:runSummary(m),cancelled:false};
        for(var q=0;q<indices.length;q++){var check=m.jobs[indices[q]];checkSource(check.template);checkSource(check.design);checkSource(check.back);if(check.surfaces)for(var si=0;si<check.surfaces.length;si++)checkSource(check.surfaces[si].design);}
        // Persist pending intent before work; completed jobs are never selected again.
        var temp=null;
        var report=new File(m.report||m.folder+'/Resumen.txt');
        var logLines=[];
        function log(t){if(t.indexOf('ALINEACION |')!==0||(request&&request.diagnostics))logLines.push(t);}
        function flushLog(){if(!logLines.length)return;report.encoding='UTF-8';if(!report.open('a'))throw Error('No se pudo escribir el resumen.');try{report.writeln(logLines.join('\n'));logLines=[];}finally{report.close();}}
        var progress;if(jobId!==undefined)progress={add:function(){return {preferredSize:{}};},show:function(){},update:function(){},close:function(){}};else progress=new Window('palette','Mockup Studio 1.3.2');progress.orientation='column';
        var label=progress.add('statictext',undefined,'Preparando');label.preferredSize.width=420;
        var bar=progress.add('progressbar',undefined,0,indices.length);bar.preferredSize=[420,14];
        var stop=progress.add('button',undefined,'Detener al terminar esta camiseta'),cancelled=false;
        stop.onClick=function(){cancelled=true;stop.enabled=false;};progress.onClose=function(){cancelled=true;return false;};
        var oldDialogs=app.displayDialogs,oldUnits=app.preferences.rulerUnits,oldDoc=app.documents.length?app.activeDocument:null,doc=null,prepared=null;
        app.displayDialogs=DialogModes.NO;app.preferences.rulerUnits=Units.PIXELS;
        try{progress.show();for(var n=0;n<indices.length&&!cancelled;n++){
            var job=m.jobs[indices[n]],s=job.settings;job.status='running';checkpoint(m,job);
            label.text=(n+1)+' / '+indices.length+' - '+job.template.name;progress.update();
            if(cancelled){job.status='pending';checkpoint(m,job);break;}
            try{
                var startedJob=new Date().getTime();doc=cachedTemplate(new File(job.template.path));var loadedJob=new Date().getTime();
                if(job.surfaces){
                    for(var si=0;si<job.surfaces.length;si++){
                        var surface=job.surfaces[si],targets=[];findLayers(doc,surface.layer,targets);
                        if(!targets.length)throw Error('No se encontro la capa visible '+surface.layer+' para '+surface.side);
                        if(surface.blank){for(var k=0;k<targets.length;k++)targets[k].visible=false;continue;}
                        for(var k=0;k<targets.length;k++)ensureEmbedded(targets[k]);
                        prepared=prepareDesign(new File(surface.design.path),temp,surface.settings);
                        for(var k=0;k<targets.length;k++)editSmart(doc,targets[k],prepared,surface.settings,log);
                        prepared.remove();prepared=null;
                    }
                }else{
                var targets=[],backs=[];findLayers(doc,s.twoSided?s.frontLayer:s.layer,targets);
                if(!targets.length)throw Error('No se encontro la capa visible '+(s.twoSided?s.frontLayer:s.layer));
                if(s.twoSided){if(s.frontLayer===s.backLayer)throw Error('Frente y espalda necesitan nombres de capa distintos.');findLayers(doc,s.backLayer,backs);if(!backs.length)throw Error('No se encontro '+s.backLayer);}
                var k;for(k=0;k<targets.length;k++)ensureEmbedded(targets[k]);for(k=0;k<backs.length;k++)ensureEmbedded(backs[k]);
                prepared=prepareDesign(new File(job.design.path),temp,s);
                for(k=0;k<targets.length;k++)editSmart(doc,targets[k],prepared,s,log);
                prepared.remove();prepared=null;
                if(s.twoSided){prepared=prepareDesign(new File(job.back.path),temp,job.backSettings);for(k=0;k<backs.length;k++)editSmart(doc,backs[k],prepared,job.backSettings,log);prepared.remove();prepared=null;}
                }
                var designTitle=job.name;if(job.surfaces)designTitle+='.png';
                var dn=Core.safeName(designTitle),tn=Core.safeName(job.template.name),base=dn+'_'+tn;if(s.naming==='template')base=tn+'_'+dn;
                if(job.surfaces)base+='_'+job.view+'_'+job.tone;
                var outputFolder=folder;if(job.brandFolder){outputFolder=new Folder(folder.fsName+'/'+job.brandFolder);mkdir(outputFolder);}
                var placedJob=new Date().getTime();job.files=exportFiles(doc,outputFolder,base,dn,tn,s,outputMode(m));var exportedJob=new Date().getTime();job.timings={templateMs:loadedJob-startedJob,placementMs:placedJob-loadedJob,exportMs:exportedJob-placedJob,totalMs:exportedJob-startedJob};log('TIMING | '+measuredEncode(job.timings));job.status='done';job.error='';log('OK | '+job.template.name+' | '+job.name);
            }catch(e){if(e.number===8007){job.status='pending';cancelled=true;}else{job.status='error';job.error=e.message;}log('ERROR | '+job.template.name+' | '+e.message);
            }finally{if(doc){try{doc.close(SaveOptions.DONOTSAVECHANGES);}catch(ignore){}doc=null;}if(prepared){try{prepared.remove();}catch(ignore){}prepared=null;}}
            checkpoint(m,job);flushLog();bar.value=n+1;progress.update();
        }}finally{app.displayDialogs=oldDialogs;app.preferences.rulerUnits=oldUnits;if(oldDoc){try{app.activeDocument=oldDoc;}catch(ignore){}}progress.onClose=null;progress.close();if(jobId===undefined)releaseTemplateCache();}
        return {manifest:m,summary:runSummary(m),cancelled:cancelled};
    }
    var registryFile=new File(dataFolder.fsName+'/brands-v1.json');
    var fastRequest=true;
    var registry=fastRequest?null:loadJSON(registryFile,null),brandContext=null;
    if(registry&&registry.active&&registry.entries['$'+registry.active])useBrand(registry.active);
    function mkdir(folder){if(folder.exists)return;var parent=folder.parent;if(parent&&!parent.exists)mkdir(parent);if(!folder.create())throw Error('No se pudo crear '+folder.fsName);}
    function persistRegistry(){mkdir(dataFolder);atomic(registryFile,registry);}
    function ensureRegistry(){if(registry)return;var settings=loadSettings();registry={version:1,root:new Folder(settings.templates).fsName,active:'',next:1,baseSettings:settings,baseState:loadState(),entries:{}};persistRegistry();}
    function useBrand(key){
        var entry=registry.entries['$'+key];if(!entry)throw Error('Marca desconocida.');
        brandContext=entry;
        var context=new Folder(dataFolder.fsName+'/brands/'+entry.storage);
        settingsFile=new File(context.fsName+'/settings-v1.txt');stateFile=new File(context.fsName+'/studio-v2.json');
    }
    function discoverBrands(){
        ensureRegistry();var root=new Folder(registry.root);if(!root.exists)throw Error('No se encuentra la carpeta principal de mockups.');
        var list=[{id:root.fsName,name:'Sin marca (carpeta principal)',path:root.fsName,kind:'root'},{id:'all:'+root.fsName,name:'Todas las marcas',path:root.fsName,kind:'all'}];
        var children=root.getFiles(),brands=[],i,f;
        for(i=0;i<children.length;i++){f=children[i];if(f instanceof Folder&&!f.alias&&f.name.charAt(0)!=='.')brands.push({id:f.fsName,name:decodeURI(f.name),path:f.fsName,kind:'brand'});}
        brands.sort(function(a,b){var x=a.name.toLowerCase(),y=b.name.toLowerCase();if(x<y)return -1;if(x>y)return 1;return 0;});
        list=list.concat(brands);return {root:registry.root,active:registry.active,brands:list};
    }
    function initialState(option){
        var seed=measuredParse(measuredEncode(registry.baseState));seed.lastRun='';seed.lastGallery='';
        if(option.kind==='all'){
            // Reuse calibrations from existing brand contexts when creating All for the first time.
            for(var key in registry.entries)if(registry.entries.hasOwnProperty(key)){
                var entry=registry.entries[key];if(entry.kind!=='brand'||!isInside(new Folder(entry.path),new Folder(option.path)))continue;
                var folder=new Folder(dataFolder.fsName+'/brands/'+entry.storage),state=loadJSON(new File(folder.fsName+'/studio-v2.json'),null);
                if(!state)continue;var cf=new File(folder.fsName+'/settings-v1.txt'),cfg=registry.baseSettings;if(cf.exists)cfg=Core.decode(readText(cf));
                var maps=['tags','favorites','excluded','thumbnails','reviews','templateRules','designRules'],mi,mk;
                for(mi=0;mi<maps.length;mi++){var map=maps[mi];if(!seed[map])seed[map]={};if(!state[map])continue;for(mk in state[map])if(state[map].hasOwnProperty(mk))seed[map][mk]=state[map][mk];}
                var files=filesIn(new Folder(entry.path),/\.(psd|psb)$/i,true),zones=['front','chest','back'];
                for(var ti=0;ti<files.length;ti++)for(var zi=0;zi<zones.length;zi++){var cs=Core.normalize(cfg);cs.zone=zones[zi];seed.profiles['$'+files[ti].fsName+'::'+zones[zi]]=Core.effective(cs,state.profiles,files[ti].fsName);}
            }
        }
        return seed;
    }
    function switchBrand(id){
        var menu=discoverBrands(),option=null;
        for(var i=0;i<menu.brands.length;i++)if(menu.brands[i].id===id)option=menu.brands[i];
        if(!option)throw Error('La marca ya no existe. Actualiza las marcas.');
        var key='$'+id,entry=registry.entries[key];
        if(!entry){
            entry={storage:'brand_'+registry.next++,name:option.name,path:option.path,kind:option.kind};
            var seed=initialState(option),cfg=Core.normalize(registry.baseSettings);
            cfg.templates=option.path;cfg.recursive=false;cfg.templateRecursive=option.kind!=='root';
            var outputName=option.name;if(option.kind==='root')outputName='Sin_marca';if(option.kind==='all')outputName='Todas_las_marcas';
            // Append a fake extension so dots in a brand name are retained by safeName.
            cfg.output=registry.baseSettings.output+'/'+Core.safeName(outputName+'.folder');
            mkdir(new Folder(cfg.output));mkdir(new Folder(dataFolder.fsName+'/brands/'+entry.storage));
            registry.entries[key]=entry;useBrand(id);saveSettings(cfg);saveState(seed);
        }else useBrand(id);
        registry.active=id;persistRegistry();
        return {settings:loadSettings(),state:loadState(),brand:brandContext,menu:discoverBrands()};
    }
    function labelForBrand(path){
        if(!brandContext)return '';
        if(brandContext.kind!=='all')return brandContext.name;
        var relative=path.substring(brandContext.path.length+1),slash=relative.indexOf('/');
        if(slash<0)return 'Sin_marca';return relative.substring(0,slash);
    }

    // Adobe PSD/PSB image resource 1036: 28-byte header followed by RGB JPEG.
    function embeddedPreview(file){
        file.encoding='BINARY';if(!file.open('r'))throw Error('No se pudo leer el PSD.');
        function bytes(n){var s=file.read(n);if(s.length!==n)throw Error('PSD incompleto.');return s;}
        function number(n){var s=bytes(n),v=0;for(var i=0;i<n;i++)v=v*256+s.charCodeAt(i);return v;}
        function seek(p){if(p<0||p>file.length||!file.seek(p,0))throw Error('Recurso PSD invalido.');}
        try{
            if(bytes(4)!=='8BPS')throw Error('Formato PSD no reconocido.');
            var version=number(2);if(version!==1&&version!==2)throw Error('Version PSD no compatible.');
            seek(26);var colorSize=number(4);seek(30+colorSize);
            var resourceSize=number(4),end=file.tell()+resourceSize;if(end>file.length)throw Error('Recursos incompletos.');
            while(file.tell()<end){
                if(bytes(4)!=='8BIM')throw Error('Recurso PSD no reconocido.');
                var id=number(2),nameLength=number(1);seek(file.tell()+nameLength+((nameLength+1)%2));
                var size=number(4),start=file.tell(),next=start+size+(size%2);if(next>end)throw Error('Recurso fuera del PSD.');
                if(id===1036&&size>=28){
                    var format=number(4);seek(start+20);var compressed=number(4);seek(start+28);
                    if(format===1&&compressed>3&&compressed<=size-28&&compressed<=8388608){
                        var jpeg=bytes(compressed);if(jpeg.charCodeAt(0)===255&&jpeg.charCodeAt(1)===216)return jpeg;
                    }
                }
                seek(next);
            }
            return null;
        }finally{file.close();}
    }
    function attachPreviews(items){
        var folder=new Folder(dataFolder.fsName+'/psd-previews');mkdir(folder);
        var indexFile=new File(folder.fsName+'/index.json'),index=loadJSON(indexFile,{next:1,entries:{}});
        for(var i=0;i<items.length;i++){
            var item=items[i],source=new File(item.path),stamp=String(source.length)+'-'+String(source.modified.getTime()),key='$'+source.fsName,entry=index.entries[key];
            try{
                if(!entry||entry.stamp!==stamp||(entry.path&&!new File(entry.path).exists)){
                    var jpeg=embeddedPreview(source);entry={stamp:stamp,path:''};
                    if(jpeg){var target=new File(folder.fsName+'/preview-'+(index.next++)+'.jpg');target.encoding='BINARY';if(!target.open('w'))throw Error('No se pudo guardar la miniatura.');try{if(!target.write(jpeg))throw Error('No se pudo guardar la miniatura.');}finally{target.close();}entry.path=target.fsName;}
                    index.entries[key]=entry;
                }
                item.preview=entry.path;
                if(!item.preview)item.previewError='PSD sin miniatura guardada';
            }catch(e){item.preview='';item.previewError='No se pudo leer la miniatura';}
        }
        atomic(indexFile,index);return items;
    }

    function handle(r){
        if(r.action==='ping')return {version:app.version,name:app.name};
        if(r.action==='bulkCreate'){
            if(!r.jobs||!r.jobs.length||r.jobs.length>10000)throw Error('Lote vacio o demasiado grande.');
            var output=new Folder(r.output);if(output.exists)throw Error('El destino del lote ya existe.');
            var jobs=[];
            for(var bi=0;bi<r.jobs.length;bi++){
                var input=r.jobs[bi],tf=new File(input.template),df=new File(input.design);
                if(!tf.exists||!df.exists)throw Error('Falta un archivo: '+(!tf.exists?tf.fsName:df.fsName));
                if(!/\.(psd|psb)$/i.test(tf.name)||! /\.(png|jpe?g|tiff?|psd|psb)$/i.test(df.name))throw Error('Formato de archivo no compatible.');
                var config=Core.defaults();config.jpg=r.format==='JPG';config.png=r.format==='PNG';config.quality=Math.max(0,Math.min(12,Math.round(r.quality*12/100)));
                if(!config.jpg&&!config.png)throw Error('Formato de salida no valido.');
                // This first bridge preserves the proven full-front smart-object placement.
                // Other diagram zones need per-template calibration, not guessed canvas coordinates.
                if(input.zone!=='front'||input.width!==42||input.x!==50||input.y!==48||input.view!=='front')throw Error('Primero calibra esta colocacion. La conexion inicial admite Frente completo sin ajustes.');
                jobs.push({id:String(bi),template:meta(tf),design:meta(df),name:decodeURI(df.name),settings:config,status:'pending',files:[],error:''});
            }
            var internal=new Folder(r.internal);if(!r.internal||internal.exists)throw Error('Destino interno no valido.');mkdir(internal);mkdir(output);
            var manifest={version:9,path:internal.fsName+'/Lote.json',report:internal.fsName+'/Resumen.txt',folder:output.fsName,kind:'bulklab',jobs:jobs};
            atomic(new File(manifest.path),manifest);$.global.BulkLabRun=manifest;
            return {manifest:manifest};
        }
        if(r.clientTiming)diagnostic(r.clientTiming);
        if(r.action==='diagnostics'){dataFolder.execute();return {};}
        if(r.action==='step'){var active=loadRun(r.path);if(!active||active.path!==r.path)throw Error('No se encontro el lote.');var result=executeRun(active,r.mode||'resume',String(r.jobId)),changed=null;for(var ji=0;ji<active.jobs.length;ji++)if(active.jobs[ji].id===String(r.jobId))changed=active.jobs[ji];return {job:changed,cancelled:result.cancelled};}
        if(r.action==='releaseCache'){releaseTemplateCache();delete $.global.BulkLabRun;return {};}
        if(r.action==='load'){releaseTemplateCache();delete $.global.BulkLabRun;}
        var st=loadState();
        if(r.action==='load')return {settings:loadSettings(),state:st,brand:brandContext};
        if(r.action==='brands')return discoverBrands();
        if(r.action==='brandSwitch')return switchBrand(r.id);
        if(r.action==='brandRoot'){
            ensureRegistry();var root=new Folder(registry.root).selectDlg(L('Carpeta que contiene las marcas','Folder containing your brands'));if(!root)return {cancelled:true};
            registry.root=root.fsName;persistRegistry();return {menu:discoverBrands()};
        }
        if(r.action==='choose'){var f=new Folder(r.path||Folder.desktop.fsName).selectDlg(L('Seleccionar carpeta','Select folder'));return {path:f?f.fsName:null};}
        if(r.action==='open'){var f=new File(r.path);if(f.exists)f=f.parent;else f=new Folder(r.path);if(!f.exists||!f.execute())throw Error('No se pudo abrir la carpeta.');return {};}
        if(r.action==='state'){var allowed={profiles:1,tags:1,favorites:1,excluded:1,reviews:1,templateRules:1,designRules:1};for(var k in r.patch)if(allowed.hasOwnProperty(k))st[k]=r.patch[k];saveState(st);return {state:st};}
        if(r.action==='history'||r.action==='resume'||r.action==='retry'){
            var path=st.lastRun;if(r.kind==='gallery')path=st.lastGallery;if(!path)return {manifest:null};
            var m=loadRun(path);if(!m)throw Error('No se encontro el lote.');
            if(r.action==='history')return {manifest:m,summary:runSummary(m)};
            if(!confirm(L('Continuar con los archivos y ajustes originales de este lote?','Continue with the original files and settings for this batch?')))return {cancelled:true};if(r.incremental)return {manifest:m,summary:runSummary(m)};return executeRun(m,r.action);
        }
        if(r.action==='import'){var f=File.openDialog(L('Cargar ajustes generales','Load default settings'),'*.bmsp');if(!f)return {};var c=Core.decode(readText(f));saveSettings(c);return {settings:c};}
        if(r.action==='preflight'){if(!/^(run|preview|gallery|quick)$/.test(r.operation))throw Error('Operacion desconocida.');r.action=r.operation;r.inspect=true;}
        var c=Core.normalize(r.settings);if(brandContext){c.templates=brandContext.path;if(brandContext.kind==='all')c.templateRecursive=true;if(brandContext.kind==='root')c.templateRecursive=false;c.recursive=false;}
        if(r.action==='save'){saveSettings(c);return {};}
        if(r.action==='export'){var f=File.saveDialog(L('Guardar ajustes generales','Save default settings'),'*.bmsp');if(!f)return {};if(!/\.bmsp$/i.test(f.name))f=new File(f.fsName+'.bmsp');if(f.exists&&!confirm(L('Reemplazar '+f.name+'?','Replace '+f.name+'?')))return {};writeText(f,Core.encode(c));return {path:f.fsName};}
        var scanConfig=Core.normalize(c);scanConfig.pairing='all';var b=plan(scanConfig,false,r.action==='scan');
        if(r.action==='scan'){var items=attachPreviews(metadata(b.templates));if(brandContext&&brandContext.kind==='all')for(var bi=0;bi<items.length;bi++)items[bi].name=labelForBrand(items[bi].path)+' / '+items[bi].name;return {templates:items,designs:designCatalog(b.designs,c)};}
        if(r.action!=='run'&&r.action!=='preview'&&r.action!=='gallery'&&r.action!=='quick')throw Error('Operacion desconocida.');
        if(r.inspect)return newRun(c,b,r,st);
        saveSettings(c);var m=newRun(c,b,r,st);if(!m)return {cancelled:true};if(r.incremental)return {manifest:m,summary:runSummary(m)};return executeRun(m,'resume');
    }
    try{if(!request){alert('Abre Mockup Studio desde Ventana > Extensiones (heredadas). Este archivo es el motor del panel.');return 'OK';}var data=handle(request),reply=measuredEncode({ok:true,data:data});diagnostic({source:'engine',action:request.action,jobId:request.jobId||'',totalMs:new Date().getTime()-requestStarted,metrics:metrics});return reply;}
    catch(error){delete $.global.BulkLabRun;try{releaseTemplateCache();}catch(ignore){}diagnostic({source:'engine',action:request?request.action:'',error:error.message,totalMs:new Date().getTime()-requestStarted,metrics:metrics});return measuredEncode({ok:false,error:error.message,issues:error.issues||[]});}
}());
